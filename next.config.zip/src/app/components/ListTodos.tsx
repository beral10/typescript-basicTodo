'use client';
import React, { useContext, useRef, useState } from 'react';
import { Todo, TodoContext } from '../context/TodoContext';

const ListTodos = () => {
	const todoCtx = useContext(TodoContext);
	const [btnToggler, setBtnToggler] = useState(false);
	const textInputRef = useRef<HTMLInputElement>(null)
	


	const editHandler = (todo: Todo, event: React.MouseEvent) => {

		setBtnToggler(!btnToggler)
		
		if (event.currentTarget.id === todo.id) {
			event.currentTarget.textContent = 'Save'
		}
		
		todoCtx?.modifyTodo(todo);

	}

;	return (
		<div>
			<ul>
				{todoCtx?.todos.map((todo) => {
					const todoText: string = todo.text;
					const limitedTodoText = todoText.length > 13 ? todoText.slice(0, 13) + '...' : todoText;

					const isEditing = (btnToggler && (textInputRef.current?.id === todo.id) )

					return (
						<li className='w-full flex items-center justify-between space-x-[22px]' key={todo.id} id={`${todo.id}`}>
							<div className='flex items-center gap-x-[22px] flex-1'>
								<input type='checkbox' name='' id='' className='w-[25px] h-[25px] border-2 border-gray-400 checked:border-blue-500' />
								<div className='relative group bg-red-100 w-full'>
									{
										isEditing 
										? <input id={todo.id} className={'text-[20px] leading-[30px]'} defaultValue={todoText} type="text"/> 
										: <p ref={textInputRef} id={todo.id} className='text-[20px] m-0 p-0 leading-[30px] bg-amber-500'>{limitedTodoText}</p>
									}
									<p className={`absolute left-1/2 -top-1/2 transform -translate-x-1/2 hidden text-[14px] leading-[18px] px-[10px] ${todoText.length > 13 ? 'group-hover:block' : null} bg-amber-600 rounded-sm z-10`}>{todoText}
									</p>
								</div>
							</div>
							<div className='space-x-[10px]'>
								<button
									type='button'
									id={todo.id}
									className='w-[90px] h-[52px] border-2 border-[#868585] bg-[#eeeeee] rounded-md text-3xl cursor-pointer'
									onClick={(event) => editHandler(todo, event)}>
									 Edit
								</button>
								<button type='button' className='w-[141px] h-[52px] border-2 border-[#868585] bg-[#eeeeee] rounded-md text-3xl cursor-pointer' onClick={() => todoCtx.deleteTodo(todo.id)}>
									Delete
								</button>
							</div>
						</li>
					);
				})}
			</ul>
		</div>
	);
};

export default ListTodos;
